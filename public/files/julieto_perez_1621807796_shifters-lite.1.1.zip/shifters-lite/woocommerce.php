<?php get_header(); ?>
<div class="container">
<div id="site_content_panel">
     <div class="left_panel_content fullwidth">  
			<?php woocommerce_content(); ?>
    </div><!-- left_panel_content-->   
</div><!-- .site_content_panel --> 
</div><!-- .container -->     
<?php get_footer(); ?>